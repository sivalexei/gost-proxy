#ifndef SOCKS5_H
#define SOCKS5_H

#include <stdint.h>

#define SOCKS5_PORT 1080

/* Запуск локального SOCKS5-прокси */
int socks5_start(uint16_t port, const char *server_ip, uint16_t server_port,
                 const uint8_t *expanded_key, uint64_t session_id,
                 int existing_udp_fd, struct sockaddr_in *server_addr,
                 uint32_t *session_counter);

/* Остановка */
void socks5_stop(void);

#endif /* SOCKS5_H */
