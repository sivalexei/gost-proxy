#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "kuznyechik.h"
#include "gost_common.h"
#include "protocol.h"

/* MAC = encrypt(xor_all_blocks_of_payload, key) */
static void compute_mac(
    const uint8_t *payload, size_t payload_len,
    const uint8_t *expanded_key,
    uint8_t *mac_out
) {
    uint8_t block[16];
    memset(block, 0, 16);

    for (size_t offset = 0; offset < payload_len; offset += 16) {
        size_t block_len = (payload_len - offset > 16) ? 16 : (payload_len - offset);
        for (size_t i = 0; i < block_len; i++)
            block[i] ^= payload[offset + i];
    }

    memcpy(mac_out, block, 16);
    kuznyechik_encrypt_block(mac_out, expanded_key);
}

static void make_ctr_nonce(const uint8_t *session_nonce, uint32_t counter, uint8_t *out16) {
    memcpy(out16, session_nonce, NONCE_SIZE);
    out16[12] = (counter >> 24) & 0xFF;
    out16[13] = (counter >> 16) & 0xFF;
    out16[14] = (counter >> 8)  & 0xFF;
    out16[15] = (counter >> 0)  & 0xFF;
}

/*
 * protocol_pack_data — шифрование и упаковка пакета данных.
 *
 * Формат payload (до шифрования):
 *   [0..3]   data_len (4 байта, big-endian)
 *   [4..3+N] данные
 *   [4+N..MAX_PAYLOAD-1] нули (padding до 1400 байт)
 *
 * После шифрования: весь 1400-байтный payload зашифрован через ГОСТ CTR.
 * MAC вычисляется от зашифрованного payload (Encrypt-then-MAC).
 */
int protocol_pack_data(
    gost_packet_t *pkt,
    uint64_t session_id,
    const uint8_t *data,
    size_t data_len,
    const uint8_t *expanded_key,
    const uint8_t *nonce,
    uint32_t *counter
) {
    if (!pkt || !data || !expanded_key || !nonce || !counter) return -1;
    if (data_len > MAX_PAYLOAD) return -1;

    memset(pkt, 0, sizeof(gost_packet_t));
    pkt->magic = htonl(GOST_PROXY_MAGIC);
    pkt->type = PKT_DATA;
    pkt->session_id = htonll(session_id);

    /* Заголовок: 4 байта data_len */
    pkt->payload[0] = (data_len >> 24) & 0xFF;
    pkt->payload[1] = (data_len >> 16) & 0xFF;
    pkt->payload[2] = (data_len >> 8)  & 0xFF;
    pkt->payload[3] = (data_len >> 0)  & 0xFF;

    /* Данные после заголовка */
    memcpy(pkt->payload + 4, data, data_len);
    /* Остальные байты payload уже нули (memset выше) */

    /* Шифруем весь 1400-байтный payload через ГОСТ CTR */
    uint8_t ctr_nonce[16];
    make_ctr_nonce(nonce, *counter, ctr_nonce);
    kuznyechik_encrypt_ctr(pkt->payload, pkt->payload, MAX_PAYLOAD, expanded_key, ctr_nonce);

    /* Encrypt-then-MAC: MAC от зашифрованного payload */
    compute_mac(pkt->payload, MAX_PAYLOAD, expanded_key, pkt->auth_tag);

    (*counter)++;
    return 0;
}

/*
 * protocol_unpack_data — расшифрование и извлечение данных.
 *
 * 1. Проверяем MAC от зашифрованного payload (Encrypt-then-MAC)
 * 2. Расшифровываем payload
 * 3. Извлекаем data_len и данные
 */
int protocol_unpack_data(
    const gost_packet_t *pkt,
    uint8_t *data,
    size_t *data_len,
    const uint8_t *expanded_key,
    const uint8_t *nonce,
    uint32_t *counter
) {
    if (!pkt || !data || !data_len || !expanded_key || !nonce || !counter) return -1;

    /* Шаг 1: Проверяем MAC от зашифрованного payload */
    uint8_t expected_mac[AUTH_TAG_SIZE];
    compute_mac(pkt->payload, MAX_PAYLOAD, expanded_key, expected_mac);
    if (memcmp(pkt->auth_tag, expected_mac, AUTH_TAG_SIZE) != 0) {
        printf("[CRYPTO] MAC не совпадает!\n");
        return -1;
    }

    /* Шаг 2: Расшифровываем payload */
    uint8_t decrypted[MAX_PAYLOAD];
    uint8_t ctr_nonce[16];
    make_ctr_nonce(nonce, *counter, ctr_nonce);
    kuznyechik_encrypt_ctr(pkt->payload, decrypted, MAX_PAYLOAD, expanded_key, ctr_nonce);

    /* Шаг 3: Извлекаем data_len */
    uint32_t dl = ((uint32_t)decrypted[0] << 24) |
                  ((uint32_t)decrypted[1] << 16) |
                  ((uint32_t)decrypted[2] << 8)  |
                  ((uint32_t)decrypted[3]);
    if (dl > MAX_PAYLOAD) return -1;

    *data_len = dl;
    memcpy(data, decrypted + 4, dl);

    (*counter)++;
    return 0;
}

int protocol_create_handshake(
    gost_packet_t *pkt,
    uint64_t session_id,
    const uint8_t *expanded_key
) {
    if (!pkt || !expanded_key) return -1;

    memset(pkt, 0, sizeof(gost_packet_t));
    pkt->magic = htonl(GOST_PROXY_MAGIC);
    pkt->type = PKT_HANDSHAKE;
    pkt->session_id = htonll(session_id);

    /* Auth tag = шифрование session_id как подпись */
    uint8_t signature[16];
    memset(signature, 0, 16);
    memcpy(signature, &session_id, 8);
    kuznyechik_encrypt_block(signature, expanded_key);
    memcpy(pkt->auth_tag, signature, AUTH_TAG_SIZE);

    return 0;
}

int protocol_verify_handshake(
    const gost_packet_t *pkt,
    const uint8_t *expanded_key
) {
    if (!pkt || !expanded_key) return -1;
    if (pkt->type != PKT_HANDSHAKE) return -1;
    if (ntohl(pkt->magic) != GOST_PROXY_MAGIC) return -1;
    return 0;
}
